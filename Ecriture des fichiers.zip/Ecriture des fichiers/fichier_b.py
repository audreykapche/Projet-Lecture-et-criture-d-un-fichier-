import pandas as pd
import numpy as np

# --- 1. CHARGEMENT ---
chemin = "C:/Users/HP/OneDrive/Desktop/BUT SD/SD1/Data (1)/Data/fichierClientB.csv"
df = pd.read_csv(chemin)

log = []

# --- EXERCICE 4 : NETTOYAGE DES DONNÉES ---

# A. Correction des années (Format 2 chiffres et Type)
def fixer_annee(val):
    try:
        v = int(float(val))
        # Si l'année est < 100 
        if v < 100:
            prefixe = 2000 if v < 26 else 1900
            return prefixe + v
        
        return v
    except:
        return np.nan

df['Year_Birth'] = df['Year_Birth'].apply(fixer_annee)
log.append("Correction des formats d'année effectuée.")
# B. Nettoyage du texte et fautes de frappe
df['Education'] = df['Education'].astype(str).str.strip().str.capitalize()
df['Marital_Status'] = df['Marital_Status'].astype(str).str.strip().str.capitalize()

# Suppression des valeurs "bruit" (Yolo, Absurd) pour les traiter comme manquantes
df.loc[df['Marital_Status'].isin(['Yolo', 'Absurd', 'Alone']), 'Marital_Status'] = np.nan
log.append("Suppression des statuts matrimoniaux incohérents (Yolo, Absurd, Alone).")

corrections = {'Widwo': 'Widow', 'Singel': 'Single', 'Maried': 'Married', 'Togeter': 'Together'}
df['Marital_Status'] = df['Marital_Status'].replace(corrections)
log.append("Correction des fautes de frappe dans Marital_Status.")

# C. Gestion des valeurs manquantes (Imputation systématique)
# Pour Income et Year_Birth : Médiane
df['Income'] = pd.to_numeric(df['Income'], errors='coerce')
for col in ['Income', 'Year_Birth']:
    mediane = df[col].median()
    if df[col].isnull().sum() > 0:
        df[col] = df[col].fillna(mediane)
        log.append(f"Imputation : {col} rempli par la médiane ({mediane})")

# Pour Education et Marital_Status : Valeurs par défaut
df['Education'] = df['Education'].replace('Nan', 'Graduation').fillna('Graduation')
df['Marital_Status'] = df['Marital_Status'].fillna('Single')
log.append("Valeurs manquantes Education et Marital_Status remplies par défaut.")

# D. Dates et Années aberrantes
df['Dt_Customer'] = pd.to_datetime(df['Dt_Customer'], dayfirst=True, errors='coerce')
df['Dt_Customer'] = df['Dt_Customer'].fillna(pd.to_datetime('2013-01-01'))

# On corrige les dates de naissance impossibles  sans supprimer les lignes
mediane_annee = df['Year_Birth'].median()
df.loc[df['Year_Birth'] < 1920, 'Year_Birth'] = mediane_annee
log.append("Correction des années de naissance aberrantes (< 1920).")


# EXERCICE 5 : COMPLÉTER LES DONNÉES 

# 1. Nombre de personnes dans le foyer
df['Conjoint'] = df['Marital_Status'].isin(['Married', 'Together']).astype(int)
# Sécurité : remplir les colonnes enfants par 0 si vides
df['Kidhome'] = df['Kidhome'].fillna(0)
df['Teenhome'] = df['Teenhome'].fillna(0)

df['Nb_personnes_foyer'] = 1 + df['Conjoint'] + df['Kidhome'] + df['Teenhome']

# 2. Revenu moyen par personne
df['Revenu_par_personne'] = df['Income'] / df['Nb_personnes_foyer']

# 3. Totaux (Commandes et Dépenses)
cols_achats = ['NumDealsPurchases', 'NumWebPurchases', 'NumCatalogPurchases', 'NumStorePurchases']
cols_depenses = ['MntWines', 'MntFruits', 'MntMeatProducts', 'MntFishProducts', 'MntSweetProducts', 'MntGoldProds']

# Remplir les NaN par 0 pour que la somme soit juste
df[cols_achats + cols_depenses] = df[cols_achats + cols_depenses].fillna(0)

df['Nb_commandes_total'] = df[cols_achats].sum(axis=1)
df['Depenses_totales'] = df[cols_depenses].sum(axis=1)

# 4. Moyennes (sécurité division par zéro avec .replace)
df['Depense_moyenne_par_commande'] = (df['Depenses_totales'] / df['Nb_commandes_total'].replace(0, np.nan)).fillna(0)
df['Depense_moyenne_par_personne'] = df['Depenses_totales'] / df['Nb_personnes_foyer']


# --- SAUVEGARDE ---
df.to_csv("fichierClientB_nettoye_complet.csv", index=False)

with open("log_modifications.txt", "w", encoding="utf-8") as f:
    for msg in log: f.write(msg + "\n")

print("Traitement des Exercices 4 et 5 terminé.")