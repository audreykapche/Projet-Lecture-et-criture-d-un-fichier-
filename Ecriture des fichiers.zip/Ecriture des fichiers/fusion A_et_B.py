import pandas as pd

# 1. Chargement des deux fichiers nettoyés
df_a = pd.read_csv("fichierClientA_nettoye_complet.csv")
df_b = pd.read_csv("fichierClientB_nettoye_complet.csv")

# 2. Fusion (Concaténation) des deux tableaux
# On les met l'un en dessous de l'autre
df_total = pd.concat([df_a, df_b], ignore_index=True)

# 3. Suppression des doublons
# Si un client avec le même ID apparaît deux fois, on ne garde que la première occurrence
nb_avant = len(df_total)
df_total = df_total.drop_duplicates(subset=['ID'], keep='first')
nb_apres = len(df_total)

# 4. Sauvegarde du fichier final
df_total.to_csv("fichierClient_fusion_Total.csv", index=False)

print(f"Fusion terminée !")
print(f"Nombre de lignes au total : {nb_avant}")
print(f"Nombre de lignes après suppression des doublons : {nb_apres}")
print(f"Fichier 'fichierClient_fusion_Total.csv' créé avec succès.")