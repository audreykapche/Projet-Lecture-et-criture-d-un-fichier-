import pandas as pd
import numpy as np

# 1. Lecture du fichier client A
chemin = "C:/Users/HP/OneDrive/Desktop/BUT SD/SD1/Data (1)/Data/fichierClientA.csv"
df = pd.read_csv(chemin)

# Liste pour stocker les actions et problèmes détectés
log = []

# Exercice 4 le nettoyage 

def nettoyage_complet(row):
    # Récupération des valeurs et gestion des cases vides (NaN) [cite: 10, 13]
    v_year = str(row['Year_Birth']).strip().lower() if pd.notna(row['Year_Birth']) else ""
    v_edu = str(row['Education']).strip().lower() if pd.notna(row['Education']) else ""
    v_mar = str(row['Marital_Status']).strip().lower() if pd.notna(row['Marital_Status']) else ""
    
    valeurs_presents = [v_year, v_edu, v_mar]
    
    # Références pour Education et Statut Marital 
    orthographe_edu = {
        'graduation': 'Graduation', 'phd': 'Phd', 'mastere': 'Master', 
        '2n cycle': '2n Cycle', 'basic': 'Basic'
    }
    orthographe_mar = {
        'married': 'Married', 'maried': 'Married', 'together': 'Together',
        'togeter': 'Together', 'single': 'Single', 'singel': 'Single',
        'divorced': 'Divorced', 'widow': 'Widow', 'widwo': 'Widow',
        'alone': 'Alone','absurd': 'Absurd', 'yolo': 'YOLO'
    }
    
    # Valeurs par défaut initiales
    annee_ok, edu_ok, mar_ok = row['Year_Birth'], row['Education'], row['Marital_Status']
    
    for val in valeurs_presents:
        if val == "" or val == "nan":
            continue
            
        # 1. CORRECTION DES ANNÉES 
        if val.isdigit():
            v_int = int(val)
            # Si l'année a 2 chiffres 
            if len(val) == 2:
                # Seuil à 26 : 25 -> 2025 / 80 -> 1980
                prefixe = 2000 if v_int < 26 else 1900
                annee_ok = prefixe + v_int
                log.append(f"Ligne {row.name} : Année '{v_year}' réparée en {annee_ok}")
            # Si l'année a 4 chiffres
            elif len(val) == 4:
                annee_ok = v_int
                log.append(f"Ligne {row.name} : Année format long '{val}' validée")
        
        # 2. CORRECTION ÉDUCATION
        elif val in orthographe_edu:
            edu_ok = orthographe_edu[val]
            log.append(f"Ligne {row.name} : Education '{v_edu}' normalisée en {edu_ok}")
            
        # 3. CORRECTION STATUT MARITAL
        elif val in orthographe_mar:
            mar_ok = orthographe_mar[val]
            log.append(f"Ligne {row.name} : Statut bizarre '{v_mar}' remplacé par {orthographe_mar[v_mar]}")

    return pd.Series([annee_ok, edu_ok, mar_ok], index=['Year_Birth', 'Education', 'Marital_Status'])

# Appliquer la réparation globale
df[['Year_Birth', 'Education', 'Marital_Status']] = df.apply(nettoyage_complet, axis=1)

# Traitement des valeurs manquantes 

# Année : Conversion forcée et médiane 
df['Year_Birth'] = pd.to_numeric(df['Year_Birth'], errors='coerce')
df['Year_Birth'] = df['Year_Birth'].fillna(df['Year_Birth'].median())

# Revenu : Conversion et médiane pour boucher les trous 
df['Income'] = pd.to_numeric(df['Income'], errors='coerce')
df['Income'] = df['Income'].fillna(df['Income'].median())

# Sécurité pour les textes
df['Education'] = df['Education'].fillna("Graduation")
df['Marital_Status'] = df['Marital_Status'].fillna("Single")

# Dates 
df['Dt_Customer'] = pd.to_datetime(df['Dt_Customer'], dayfirst=True, errors='coerce')
df['Dt_Customer'] = df['Dt_Customer'].fillna(pd.to_datetime('2013-01-01'))


# Exercice 5 ajouts des colonnes et les calculs:

# Nettoyage des enfants (NaN -> 0) 
df['Kidhome'] = pd.to_numeric(df['Kidhome'], errors='coerce').fillna(0)
df['Teenhome'] = pd.to_numeric(df['Teenhome'], errors='coerce').fillna(0)

df['Conjoint'] = df['Marital_Status'].isin(['Married', 'Together']).astype(int)
df['Nb_personnes_foyer'] = 1 + df['Conjoint'] + df['Kidhome'] + df['Teenhome']
df['Revenu_par_personne'] = df['Income'] / df['Nb_personnes_foyer']

# Achats et Dépenses (NaN -> 0) 
cols_achats = ['NumDealsPurchases', 'NumWebPurchases', 'NumCatalogPurchases', 'NumStorePurchases']
cols_depenses = ['MntWines', 'MntFruits', 'MntMeatProducts', 'MntFishProducts', 'MntSweetProducts', 'MntGoldProds']
df[cols_achats + cols_depenses] = df[cols_achats + cols_depenses].fillna(0)

df['Nb_commandes_total'] = df[cols_achats].sum(axis=1)
df['Depenses_totales'] = df[cols_depenses].sum(axis=1)

# Moyennes sécurisées
df['Depense_moyenne_par_commande'] = (df['Depenses_totales'] / df['Nb_commandes_total'].replace(0, np.nan)).fillna(0)
df['Depense_moyenne_par_personne'] = df['Depenses_totales'] / df['Nb_personnes_foyer']

# --- SAUVEGARDE ---

# Sauvegarde du fichier final
df.to_csv("fichierClientA_nettoye_complet.csv", index=False)

# Ajout des informations dans le log modifications 
with open("log_modifications.txt", "a", encoding="utf-8") as fichier_log:
    fichier_log.write("=== Log fichier A ===\n")
    for ligne in log:
        fichier_log.write(ligne + "\n")

# Affichage de contrôle
print("Traitement du fichier A terminé")
print(df.head())